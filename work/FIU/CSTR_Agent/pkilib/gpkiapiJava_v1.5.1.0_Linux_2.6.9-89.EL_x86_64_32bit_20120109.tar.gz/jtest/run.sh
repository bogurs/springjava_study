rm *.class
javac -classpath ../jar/libgpkiapi_jni.jar *.java
java -classpath ../jar/libgpkiapi_jni.jar:. Main
